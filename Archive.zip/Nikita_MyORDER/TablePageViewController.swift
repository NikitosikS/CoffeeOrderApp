//Name: Nikita Sushko
//ID: 105075196

import UIKit

import CoreData

class TablePageViewController: UIViewController, UITextFieldDelegate {
    private var info1 : [Order] = [Order]()
    var info = [""]
    var info2 = [""]

    @IBOutlet weak var infoTable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
        infoTable.delegate = self
        infoTable.dataSource = self
    }
    
    func getData(){
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Order")
        request.returnsObjectsAsFaults = false
        do {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject]
            {
                info2.append(data.value(forKey: "cType") as! String)
                info2.append(data.value(forKey: "cSize") as! String)
                info2.append(data.value(forKey: "cQuantity") as! String)
                info2.append("")
            }
        }catch {
                print("Failed");
            }
        
    }
}

extension TablePageViewController: UITableViewDelegate{
    //TODO
}

extension TablePageViewController: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return info2.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = infoTable.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
       
        //cell.textLabel?.text = info[indexPath.row]
        cell.textLabel?.text = info2[indexPath.row]
        return cell
    }
    
    
}
